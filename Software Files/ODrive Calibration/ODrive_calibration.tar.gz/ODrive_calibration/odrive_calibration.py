
#This configuration is based on the guidline provided by the ODrive robotics team at their Website at https://docs.odriverobotics.com/hoverboard.html for hoverboad motors.

import sys
import time
import math
import odrive
from odrive.enums import *
import fibre.libfibre
from fibre import Logger, Event
from odrive.utils import OperationAbortedException
#from fibre.protocol import ChannelBrokenException


# Min/Max phase inductance of motor
MIN_PHASE_INDUCTANCE = 0
MAX_PHASE_INDUCTANCE = 0.001
    
# Min/Max phase resistance of motor
MIN_PHASE_RESISTANCE = 0
MAX_PHASE_RESISTANCE = 0.5
    
# Tolerance for encoder offset float
ENCODER_OFFSET_FLOAT_TOLERANCE = 0.5

#  Calibration time
motor_calibration_time = 15
encoder_calibration_time = 25

input("Are you sure that the wheels are free to spin? If yes,\nPress ENTER key to proceed")
print("During the calibration, you should hear a beep...")    
 
#  Connect to ODrive   
print("Searching for ODrive...")
odrv0 = odrive.find_any()
print("Odrive detected!")

#  Motor Calibration
odrv0.axis0.requested_state = 4 # AXIS_STATE_MOTOR_CALIBRATION
odrv0.axis1.requested_state = 4 # AXIS_STATE_MOTOR_CALIBRATION
#  Wait for the calibration time
time.sleep(motor_calibration_time)
if odrv0.axis0.motor.error == 0 and odrv0.axis1.motor.error == 0:
    pass
else:
    print("Error: Odrive reported an error of {} for axis0 and error of {} for axis1 while in the state " 
    "AXIS_STATE_MOTOR_CALIBRATION. Printing out the data for 
    "debug: Axis0: {}  and Axis1: \n{}".format(odrv0.axis0.motor.error,
                        odrv0.axis1.motor.error,
                        odrv0.axis0.motor,
                        odrv0.axis1.motor))
    sys.exit(1)

if odrv0.axis0.motor.config.phase_inductance <= MIN_PHASE_INDUCTANCE or \
odrv0.axis0.motor.config.phase_inductance >= MAX_PHASE_INDUCTANCE:
            print("Error: After odrive motor calibration, the phase inductance "
            "is at {}, which is outside of the expected range. Either widen the "
            "boundaries of MIN_PHASE_INDUCTANCE and MAX_PHASE_INDUCTANCE (which "
            "is between {} and {} respectively) or debug/fix your setup. Printing "
            "out Odrive motor data for debug:\n{}".format(odrv0.axis0.motor.config.phase_inductance, 
                                                          MIN_PHASE_INDUCTANCE,
                                                          MAX_PHASE_INDUCTANCE, 
                                                          odrv0.axis0.motor))            
            sys.exit(1)

if odrv0.axis1.motor.config.phase_inductance <= MIN_PHASE_INDUCTANCE or \
odrv0.axis1.motor.config.phase_inductance >= MAX_PHASE_INDUCTANCE:
            print("Error: After odrive motor calibration, the phase inductance "
            "is at {}, which is outside of the expected range. Either widen the "
            "boundaries of MIN_PHASE_INDUCTANCE and MAX_PHASE_INDUCTANCE (which "
            "is between {} and {} respectively) or debug/fix your setup. Printing "
            "out Odrive motor data for debug:\n{}".format(odrv0.axis1.motor.config.phase_inductance, 
                                                          MIN_PHASE_INDUCTANCE,
                                                          MAX_PHASE_INDUCTANCE, 
                                                          odrv0.axis1.motor))
            
            sys.exit(1)

if odrv0.axis0.motor.config.phase_resistance <= MIN_PHASE_RESISTANCE or \
odrv0.axis0.motor.config.phase_resistance >= MAX_PHASE_RESISTANCE:
            print("Error: After odrive motor calibration, the phase resistance "
            "is at {}, which is outside of the expected range. Either raise the "
            "MAX_PHASE_RESISTANCE (which is between {} and {} respectively) or "
            "debug/fix your setup. Printing out Odrive motor data for " 
            "debug:\n{}".format(odrv0.axis0.motor.config.phase_resistance, 
                                MIN_PHASE_RESISTANCE,
                                MAX_PHASE_RESISTANCE, 
                                odrv0.axis0.motor))
            
            sys.exit(1)
if odrv0.axis1.motor.config.phase_resistance <= MIN_PHASE_RESISTANCE or \
odrv0.axis1.motor.config.phase_resistance >= MAX_PHASE_RESISTANCE:
            print("Error: After odrive motor calibration, the phase resistance "
            "is at {}, which is outside of the expected range. Either raise the "
            "MAX_PHASE_RESISTANCE (which is between {} and {} respectively) or "
            "debug/fix your setup. Printing out Odrive motor data for " 
            "debug:\n{}".format(odrv0.axis1.motor.config.phase_resistance, 
                                MIN_PHASE_RESISTANCE,
                                MAX_PHASE_RESISTANCE, 
                                odrv0.axis1.motor))
            
            sys.exit(1)


if odrv0.axis0.motor.is_calibrated == 1 and odrv0.axis1.motor.is_calibrated == 1:
    print("Motor successfully calibrated! Proceeding...")
else:
    print("Could not calibrate motor. Something went wrong.")
    print("Have you ran parameter configurstion script to set all the parameters?")
    print("If yes and the wiring looks good, reset the ODrive and try again.\nExiting.")
    quit()

        # If all looks good, then lets tell ODrive that saving this calibration 
        # to persistent memory is OK
print("Saving motor calibration")
odrv0.axis0.motor.config.pre_calibrated = True
odrv0.axis1.motor.config.pre_calibrated = True

        # Check the alignment between the motor and the hall sensor. Because of 
        # this step you are allowed to plug the motor phases in random order and
        # also the hall signals can be random. Just don’t change it after 
        # calibration.
print("Calibrating encoder offset...")
odrv0.axis0.requested_state = 12 #AXIS_STATE_ENCODER_HALL_POLARITY_CALIBRATION
odrv0.axis1.requested_state = 12 #AXIS_STATE_ENCODER_HALL_POLARITY_CALIBRATION
# Wait for calibration to take place
time.sleep(encoder_calibration_time)
odrv0.axis0.requested_state = 7 # AXIS_STATE_ENCODER_OFFSET_CALIBRATION
odrv0.axis1.requested_state = 7 # AXIS_STATE_ENCODER_OFFSET_CALIBRATION
# Wait for calibration to take place
time.sleep(encoder_calibration_time)

if odrv0.axis0.encoder.error == 0 and odrv0.axis1.encoder.error == 0:
	pass
else:
      print("Error: Odrive reported an error of {} for axis0 and {} for axis1, while in the state "
            "AXIS_STATE_ENCODER_OFFSET_CALIBRATION. Printing out Odrive encoder "
            "data for debug: Axis0: {}  and Axis1: \n{}".format(odrv0.axis0.encoder.error,
                        odrv0.axis1.encoder.error,
                        odrv0.axis0.encoder,
                        odrv0.axis1.encoder))
 #    sys.exit(1)
       
       
        # If offset_float isn't 0.5 within some tolerance, or its not 1.5 within
        # some tolerance, raise an error
        
if odrv0.axis0.encoder.is_ready == 1 and odrv0.axis1.encoder.is_ready == 1:
    print("Encoder offset successfully calibrated! Proceeding...")
   
else:
    print("Could not calibrate encoder offset. Something is wrong.")
    print("Have you ran the first script to set all parameters?")
    print("If yes and the wiring looks good, reset the ODrive and try again.\nExiting.")
    quit()

    # If all looks good, then lets tell ODrive that saving this calibration
    # to persistent memory is OK
print("Saving encoder offset calibration")
odrv0.axis0.encoder.config.pre_calibrated = True
odrv0.axis1.encoder.config.pre_calibrated = True       
       
print("Saving calibration configuration and rebooting...")       
#odrv0.save_configuration()
#print("Calibration configuration saved.")
try:
    odrv0.save_configuration()
    odrv0.reboot()
except:
    print("USB connection crashes during reboot - that is to be expected.")
    print("Probably all is good.")
    print("Odrive configuration finished.")
    print("The ODrive is now ready to be used in HoverBot!")
"""           
print(********  "Put the motor in idle so that it can move freely *********")        
odrv0 = odrive.find_any()
print("Odrive detected!")        
odrv0.axis0.requested_state = AXIS_STATE_IDLE
odrv0.axis1.requested_state = AXIS_STATE_IDLE
"""
        
