
#This configuration is based on the guidline provided by the ODrive robotics team at their Website at https://docs.odriverobotics.com/hoverboard.html for hoverboad motors.

import sys
import time
import math
import odrive
from odrive.enums import *
import fibre.libfibre
from fibre import Logger, Event
from odrive.utils import OperationAbortedException
#from fibre.protocol import ChannelBrokenException


# Define the parameters for the hoverboard
dc_bus_undervoltage_trip_level = 8
dc_bus_overvoltage_trip_level = 43
hoverboard_KV = 16.0
pole_pairs = 15
resistance_calib_max_voltage = 10
requested_current_range = 25
current_control_bandwidth = 100
cpr = pole_pairs * 6
encoder_bandwidth = 250
vel_limit = 10
current_limit = 10
calib_scan_distance = 150
torque_constant = 8.27 / hoverboard_KV
pos_gain = 1
  
# Connect to the ODrive controller   
print("Searching for ODrive...")
odrv0 = odrive.find_any()
print("Odrive detected!")

# Erase any existing Configurations and reboot
try:
	odrv0.erase_configuration()
	odrv0.reboot()
except: 
	print("Existing configurations erased")

#  Re-connect to the ODrive controller after reboot
print("Reconnecting to ODrive...")
odrv0 = odrive.find_any()
     
#  Configure the motor parameters
print(" Configuring the motor parameters")

# Enable the brake resistance and dc max negative current
odrv0.config.enable_brake_resistor = True
odrv0.config.dc_max_negative_current = -10

# Set DC voltage limits
odrv0.config.dc_bus_undervoltage_trip_level = dc_bus_undervoltage_trip_level
odrv0.config.dc_bus_overvoltage_trip_level = dc_bus_overvoltage_trip_level

#  Set the number of pole pairs
odrv0.axis0.motor.config.pole_pairs = pole_pairs
odrv0.axis1.motor.config.pole_pairs = pole_pairs

#  Set the maximum calibration voltage
odrv0.axis0.motor.config.resistance_calib_max_voltage = resistance_calib_max_voltage
odrv0.axis1.motor.config.resistance_calib_max_voltage = resistance_calib_max_voltage

#  Set the current range
odrv0.axis0.motor.config.requested_current_range   = requested_current_range
odrv0.axis1.motor.config.requested_current_range   = requested_current_range

#  Set the current control bandwidth
odrv0.axis0.motor.config.current_control_bandwidth    = current_control_bandwidth
odrv0.axis1.motor.config.current_control_bandwidth    = current_control_bandwidth

#  Set the motor torque constant
odrv0.axis0.motor.config.torque_constant = torque_constant
odrv0.axis1.motor.config.torque_constant = torque_constant

# Configure hall effect encoder parameters
print("Configuring the hall effect encoder parameters")

#  Set the configuration mode              
odrv0.axis0.encoder.config.mode = 1 #ENCODER_MODE_HALL
odrv0.axis1.encoder.config.mode = 1 #ENCODER_MODE_HALL

#  Set the hall effect encoder resolution
odrv0.axis0.encoder.config.cpr = cpr
odrv0.axis1.encoder.config.cpr = cpr

#  Set the offset calibration displacement to get better calibration accuracy
odrv0.axis0.encoder.config.calib_scan_distance = calib_scan_distance
odrv0.axis1.encoder.config.calib_scan_distance = calib_scan_distance

 # Configure GPIO for hall sensors of motor0
odrv0.config.gpio9_mode = odrive.enums.GPIO_MODE_DIGITAL
odrv0.config.gpio10_mode = odrive.enums.GPIO_MODE_DIGITAL
odrv0.config.gpio11_mode = odrive.enums.GPIO_MODE_DIGITAL
    
    # Configure GPIO for hall sensors of motor1
odrv0.config.gpio3_mode = odrive.enums.GPIO_MODE_DIGITAL
odrv0.config.gpio4_mode = odrive.enums.GPIO_MODE_DIGITAL
odrv0.config.gpio5_mode = odrive.enums.GPIO_MODE_DIGITAL
 
#  Set the hall effect encoder bandwidth
odrv0.axis0.encoder.config.bandwidth = encoder_bandwidth
odrv0.axis1.encoder.config.bandwidth = encoder_bandwidth
        
#  Configure the controller parameters
print("Configuring the controller parameters")

#  Set the position gain
odrv0.axis0.controller.config.pos_gain = pos_gain
odrv0.axis1.controller.config.pos_gain = pos_gain

#  Set the velocity gain
odrv0.axis0.controller.config.vel_gain =  0.02 * odrv0.axis0.motor.config.torque_constant * odrv0.axis0.encoder.config.cpr
odrv0.axis1.controller.config.vel_gain =  0.02 * odrv0.axis1.motor.config.torque_constant * odrv0.axis1.encoder.config.cpr

#  Set the integrator gain
odrv0.axis0.controller.config.vel_integrator_gain = 0.1 * odrv0.axis0.motor.config.torque_constant * odrv0.axis0.encoder.config.cpr
odrv0.axis1.controller.config.vel_integrator_gain = 0.1 * odrv0.axis1.motor.config.torque_constant * odrv0.axis1.encoder.config.cpr

#  Set the velocity limit
odrv0.axis0.controller.config.vel_limit = vel_limit
odrv0.axis1.controller.config.vel_limit = vel_limit

#  Set the control mode so that we can control the wheels

#odrv0.axis0.controller.config.control_mode = 1 #CTRL_MODE_CURRENT_CONTROL
#odrv0.axis1.controller.config.control_mode = 1 #CTRL_MODE_CURRENT_CONTROL
odrv0.axis0.controller.config.control_mode = 2 #CTRL_MODE_VELOCITY_CONTROL
odrv0.axis1.controller.config.control_mode = 2 #CTRL_MODE_VELOCITY_CONTROL
#odrv0.axis0.controller.config.control_mode = 3 #CONTROL_MODE_POSITION_CONTROL
#odrv0.axis1.controller.config.control_mode = 3 #CONTROL_MODE_POSITION_CONTROL
        
#  Save the configuration and reboot
print("Saving the configuration and rebooting...")
try:
     odrv0.save_configuration()
     odrv0.reboot()
except:
        print("Configuration saved, ready for calibration")
        
        
